# Aegis Airspace Security

A static, offline-capable airspace dashboard with simulated telemetry, trajectory prediction, explainable threat scoring, and browser-based location intelligence.

## Run locally

Use Node.js 18+ and run:

```bash
npm install
npm start
```

Open `http://localhost:3000`. The local demo login is `operator` / `aegis2026`; its access session is stored only in browser session storage. The Node script is a static-file preview server and exposes no application API.

## Location intelligence

The panel can use browser GPS with permission, IP geolocation from `ipapi.co` or GeoJS, and OpenStreetMap Nominatim reverse geocoding. IP coordinates are provider estimates, not a precise physical device location. The panel shows WGS84 coordinates, a coordinate-centered Esri World Street Map preview, and a clearer Esri World Imagery preview. Select either image to open the interactive map or a higher-resolution satellite image. Source credits remain visible next to the previews. Network lookups are best-effort and pause offline.

## Cloudflare static hosting

Wrangler is included as a development dependency. `wrangler.toml` serves only the static frontend from `dist/`; there is no Cloudflare Worker API or database binding.

```bash
npm install
npm run build:cloudflare
npm run cloudflare:dev
```

To publish, authenticate Wrangler with the intended Cloudflare account using `npx wrangler login`, then run `npm run deploy:cloudflare`. See [Cloudflare deployment notes](CLOUDFLARE_DEPLOYMENT.md).

## Firebase status

No Firebase project is connected and dashboard telemetry remains simulated in the browser. The project now includes a Firestore-only config, owner-scoped security rules, and deployment instructions. Persistent client data is not enabled because a Firebase project and Firebase Authentication configuration are still needed; the dashboard's demo login is not Firebase authentication. See [Firebase setup notes](firebase/README.md). Never place Firebase service-account credentials in frontend code.
