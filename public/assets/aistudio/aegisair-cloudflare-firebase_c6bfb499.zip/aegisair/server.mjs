import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { createReadStream } from "node:fs";
import { extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL(".", import.meta.url));
const port = Number(process.env.PORT || 3000);
const mime = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".webp": "image/webp", ".svg": "image/svg+xml" };

const safePath = (requestUrl) => {
  const pathname = decodeURIComponent(new URL(requestUrl, "http://localhost").pathname);
  const relative = pathname === "/" ? "index.html" : pathname.replace(/^\/+/, "");
  const candidate = normalize(join(root, relative));
  if (relative.startsWith("assets/")) return candidate;
  return candidate.startsWith(root) ? candidate : join(root, "index.html");
};

const server = createServer(async (request, response) => {
  try {
    const filePath = safePath(request.url || "/");
    let fileStat;
    try { fileStat = await stat(filePath); } catch (_) { fileStat = null; }
    const resolved = fileStat?.isFile() ? filePath : join(root, "index.html");
    response.writeHead(200, { "content-type": mime[extname(resolved)] || "text/plain; charset=utf-8", "cache-control": extname(resolved) === ".html" || resolved.endsWith("/sw.js") ? "no-cache" : "public, max-age=3600" });
    createReadStream(resolved).pipe(response);
  } catch (error) {
    response.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
    response.end("Aegis preview error");
  }
});
server.listen(port, "0.0.0.0", () => console.log(`Aegis Airspace listening on http://0.0.0.0:${port}`));
