# Firebase / Firestore setup

This folder is a Firestore setup scaffold only. No Firebase project ID, web-app config, SDK, or user data connection is included. The dashboard continues to use simulated telemetry until a Firebase project and Firebase Authentication are configured deliberately.

## Create and select a project

1. Create or choose a Firebase project in the Firebase console and create its Firestore database.
2. Enable an Authentication provider that fits the intended operators. The dashboard's `operator` / `aegis2026` demo gate only stores a session flag in the browser; it does not authenticate a Firebase user and cannot authorize Firestore access.
3. Copy `.firebaserc.example` to `.firebaserc` and replace the placeholder with the intended Firebase project ID. Do not commit the resulting project-selection file if it identifies a private project.
4. Sign in to the Firebase CLI using an authorized account:

   ```bash
   npx firebase-tools login
   ```

5. Review `firebase/firestore.rules` before deployment, then publish only Firestore rules and indexes:

   ```bash
   npx firebase-tools deploy --only firestore:rules,firestore:indexes --project YOUR_FIREBASE_PROJECT_ID
   ```

The root `firebase.json` points the CLI at these two Firestore files. It does not configure Firebase Hosting, so Cloudflare remains the website host.

## Proposed data boundary

When Firebase client integration is added, store operator-owned records below `users/{uid}`, for example `users/{uid}/tracks/{trackId}`, `users/{uid}/alerts/{alertId}`, and `users/{uid}/settings/preferences`. The current rules allow authenticated users to access only the document tree whose user ID matches their Firebase Authentication UID. All other paths remain denied by Firestore's default-deny behavior.

Before enabling persistence, connect the Firebase client SDK using the web-app configuration from the Firebase console and use a real Firebase Auth user. The client configuration is not a service-account credential, but it must still be paired with correct Firestore rules. Never include service-account JSON or Admin SDK private keys in the browser or in this static project.
