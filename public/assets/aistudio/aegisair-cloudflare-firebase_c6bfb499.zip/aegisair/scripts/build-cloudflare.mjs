import { cp, mkdir, rm } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const projectRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const outputDir = join(projectRoot, "dist");
const publicFiles = ["index.html", "styles.css", "app.js", "sw.js", "manifest.json"];

await rm(outputDir, { recursive: true, force: true });
await mkdir(join(outputDir, "assets"), { recursive: true });

for (const file of publicFiles) {
  await cp(join(projectRoot, file), join(outputDir, file));
}
await cp(join(projectRoot, "public", "assets"), join(outputDir, "assets"), { recursive: true });

console.log(`Cloudflare assets staged in ${outputDir}`);
