const STORAGE_KEY = "aegis-airspace-state";
const ACCESS_KEY = "aegis-system-access";
const SPEEDS = { slow: 2600, normal: 1400, fast: 700 };
const scenarioMeta = {
  normal: { label: "Routine airspace picture", intro: "Baseline traffic with stable vectors", boost: 0, restrictedBias: 0.1 },
  anomalous: { label: "Probing behavior detected", intro: "Unscheduled vector changes in east corridor", boost: 18, restrictedBias: 0.35 },
  "high-threat": { label: "Active incursion exercise", intro: "Multiple objects converging on protected core", boost: 31, restrictedBias: 0.65 }
};
const seedTracks = [
  { id: "AX-204", callsign: "RAVEN", type: "UNKNOWN UAV", symbol: "◇", x: 61, y: 30, altitude: 1280, speed: 68, heading: 124, confidence: 82, behavior: "probing", home: "EAST CORRIDOR", restricted: true, accent: "red" },
  { id: "DR-118", callsign: "KITE", type: "QUADCOPTER", symbol: "✦", x: 31, y: 57, altitude: 480, speed: 42, heading: 248, confidence: 94, behavior: "steady", home: "NORTHWEST", restricted: false, accent: "amber" },
  { id: "BX-077", callsign: "FALCON", type: "FIXED-WING", symbol: "△", x: 78, y: 68, altitude: 2100, speed: 114, heading: 301, confidence: 96, behavior: "steady", home: "SOUTHERN ARC", restricted: false, accent: "cyan" },
  { id: "HX-052", callsign: "MICA", type: "HELICOPTER", symbol: "◒", x: 43, y: 22, altitude: 760, speed: 54, heading: 178, confidence: 91, behavior: "loitering", home: "NORTH GATE", restricted: false, accent: "cyan" },
  { id: "SX-441", callsign: "SABLE", type: "UNKNOWN UAV", symbol: "◇", x: 19, y: 35, altitude: 990, speed: 73, heading: 76, confidence: 78, behavior: "erratic", home: "WEST EDGE", restricted: false, accent: "amber" },
  { id: "DR-390", callsign: "ORBIT", type: "QUADCOPTER", symbol: "✦", x: 69, y: 50, altitude: 330, speed: 29, heading: 222, confidence: 88, behavior: "steady", home: "SOUTHEAST", restricted: false, accent: "cyan" },
  { id: "BX-312", callsign: "NOMAD", type: "FIXED-WING", symbol: "△", x: 53, y: 78, altitude: 1780, speed: 98, heading: 14, confidence: 97, behavior: "transit", home: "SOUTHERN ARC", restricted: false, accent: "cyan" },
  { id: "HX-903", callsign: "EMBER", type: "HELICOPTER", symbol: "◒", x: 87, y: 39, altitude: 620, speed: 48, heading: 196, confidence: 93, behavior: "loitering", home: "EAST EDGE", restricted: false, accent: "amber" }
];

let state = {
  scenario: "normal",
  speed: "normal",
  paused: false,
  tick: 42,
  selectedId: "AX-204",
  alertFilter: "all",
  sortThreat: true,
  acknowledged: {},
  tracks: [],
  events: [],
  online: navigator.onLine,
  lastTickAt: Date.now()
};
let timerId;
let deferredInstall;
let deviceWatchId = null;
let deviceLocation = null;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const pad = (value) => String(value).padStart(2, "0");
const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
const timeLabel = (date = new Date()) => `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}:${pad(date.getUTCSeconds())}`;
const numberLabel = (value) => new Intl.NumberFormat("en-IN").format(Math.round(value));

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    state.scenario = scenarioMeta[saved.scenario] ? saved.scenario : "normal";
    state.speed = SPEEDS[saved.speed] ? saved.speed : "normal";
    state.acknowledged = saved.acknowledged || {};
  } catch (_) { /* local storage is optional for offline mode */ }
  resetSimulation(false);
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ scenario: state.scenario, speed: state.speed, acknowledged: state.acknowledged }));
}

function buildTracks() {
  const profile = scenarioMeta[state.scenario];
  return seedTracks.map((seed, index) => {
    const track = { ...seed, history: [], age: 0, heading: seed.heading, confidence: seed.confidence };
    if (state.scenario === "anomalous" && [0, 4, 7].includes(index)) {
      track.behavior = index === 4 ? "erratic" : "probing";
      track.restricted = index === 0 || index === 7;
      track.speed += index === 4 ? 18 : 9;
      track.confidence -= 5;
    }
    if (state.scenario === "high-threat" && [0, 1, 4, 7].includes(index)) {
      track.restricted = true;
      track.behavior = index === 1 ? "erratic" : "probing";
      track.speed += index === 1 ? 21 : 14;
      track.heading = index === 0 ? 142 : index === 7 ? 226 : track.heading;
      track.confidence -= index === 4 ? 11 : 4;
    }
    track.scenarioBoost = profile.boost;
    track.history.push(track.altitude);
    return scoreTrack(track);
  });
}

function scoreTrack(track) {
  const distanceFromCore = Math.hypot(track.x - 52, track.y - 49);
  const proximity = clamp(100 - distanceFromCore * 1.8, 8, 100);
  const speedAnomaly = clamp(Math.abs(track.speed - 52) * 1.55, 5, 100);
  const restricted = track.restricted ? 100 : 7;
  const behavior = { steady: 9, transit: 17, loitering: 46, probing: 78, erratic: 92 }[track.behavior] || 20;
  const lowConfidence = clamp(100 - track.confidence, 4, 100);
  const scenarioWeight = track.scenarioBoost || 0;
  const score = Math.round(clamp(proximity * .28 + speedAnomaly * .16 + restricted * .26 + behavior * .2 + lowConfidence * .1 + scenarioWeight, 0, 99));
  const level = score >= 78 ? "critical" : score >= 57 ? "high" : score >= 31 ? "watch" : "low";
  const reasons = [];
  if (track.restricted) reasons.push("Restricted-zone entry");
  if (proximity > 65) reasons.push("Proximity to protected core");
  if (behavior === 92 || behavior === 78) reasons.push(`${track.behavior[0].toUpperCase()}${track.behavior.slice(1)} vector behavior`);
  if (speedAnomaly > 45) reasons.push("Speed deviation from profile");
  if (track.confidence < 85) reasons.push("Classification confidence below threshold");
  if (!reasons.length) reasons.push("No priority indicators detected");
  return { ...track, score, level, proximity: Math.round(proximity), speedAnomaly: Math.round(speedAnomaly), behaviorScore: behavior, lowConfidence: Math.round(lowConfidence), reasons, eta: Math.max(18, Math.round((100 - proximity) * 1.25 + 15)) };
}

function resetSimulation(announce = true) {
  state.tick = 42;
  state.tracks = buildTracks();
  state.selectedId = state.tracks.find((track) => track.id === "AX-204")?.id || state.tracks[0]?.id;
  state.events = [
    { time: timeLabel(), label: "Simulation reset", detail: `${scenarioMeta[state.scenario].label} loaded`, tone: "cyan" },
    { time: timeLabel(), label: "Sensor fusion online", detail: `${state.tracks.length} objects acquired`, tone: "green" },
    { time: timeLabel(), label: "Prediction model ready", detail: "Weighted vector fit / 90 sec horizon", tone: "violet" }
  ];
  state.lastTickAt = Date.now();
  if (announce) addEvent("Scenario changed", scenarioMeta[state.scenario].intro, "amber");
  syncControls();
  renderAll();
  restartTimer();
  saveState();
}

function addEvent(label, detail, tone = "cyan") {
  state.events.unshift({ time: timeLabel(), label, detail, tone });
  state.events = state.events.slice(0, 8);
}

function predictedPoints(track) {
  const radians = (track.heading * Math.PI) / 180;
  const dx = Math.sin(radians) * 1.9;
  const dy = -Math.cos(radians) * 1.9;
  return [0, 1, 2, 3, 4].map((step) => ({ x: clamp(track.x + dx * step * 10, 4, 96), y: clamp(track.y + dy * step * 10, 7, 93) }));
}

function tick() {
  if (state.paused) return;
  state.tick += 1;
  state.lastTickAt = Date.now();
  state.tracks = state.tracks.map((track) => {
    const next = { ...track };
    const radians = (track.heading * Math.PI) / 180;
    const drift = track.behavior === "erratic" ? (Math.random() - .5) * 42 : (Math.random() - .5) * 9;
    next.heading = Math.round((track.heading + drift + 360) % 360);
    const travel = .14 + track.speed / 1250;
    next.x = clamp(track.x + Math.sin(radians) * travel, 5, 95);
    next.y = clamp(track.y - Math.cos(radians) * travel, 7, 93);
    next.speed = Math.max(12, Math.round(track.speed + (Math.random() - .5) * (track.behavior === "erratic" ? 18 : 6)));
    next.altitude = Math.max(120, Math.round(track.altitude + (Math.random() - .5) * (track.behavior === "probing" ? 110 : 45)));
    next.confidence = clamp(Math.round(track.confidence + (Math.random() - .5) * 3), 63, 99);
    next.history = [...track.history, next.altitude].slice(-18);
    return scoreTrack(next);
  });
  const selected = state.tracks.find((track) => track.id === state.selectedId);
  if (selected && selected.level === "critical" && state.tick % 3 === 0) addEvent("Escalation watch", `${selected.id} remains inside protected envelope`, "red");
  if (state.tick % 5 === 0) addEvent("Telemetry sweep", `${state.tracks.length} tracks refreshed`, "cyan");
  renderAll();
}

function restartTimer() {
  clearInterval(timerId);
  const offlineMultiplier = state.online ? 1 : 2;
  timerId = setInterval(tick, SPEEDS[state.speed] * offlineMultiplier);
}

function threatCounts() {
  return state.tracks.reduce((counts, track) => { counts[track.level] = (counts[track.level] || 0) + 1; return counts; }, { critical: 0, high: 0, watch: 0, low: 0 });
}

function colorFor(level) { return ({ critical: "#d65458", high: "#e36e4e", watch: "#e59c2b", low: "#1da98a" }[level] || "#00a7bd"); }

function renderMetrics() {
  const counts = threatCounts();
  const avgConfidence = state.tracks.reduce((sum, track) => sum + track.confidence, 0) / Math.max(state.tracks.length, 1);
  $("#metric-active").textContent = pad(state.tracks.length);
  $("#metric-alerts").textContent = pad(counts.critical + counts.high);
  $("#metric-confidence").innerHTML = `${avgConfidence.toFixed(1)}<span class="metric-unit">%</span>`;
  $("#metric-status").textContent = counts.critical ? "ESCALATED" : counts.high ? "GUARDED" : "CLEAR";
  $("#metric-zone-count").textContent = `${state.tracks.filter((track) => track.restricted).length.toString().padStart(2, "0")} restricted zones active`;
  $("#nav-alert-count").textContent = counts.critical + counts.high;
  $("#filter-all-count").textContent = pad(state.tracks.length);
  $("#filter-critical-count").textContent = pad(counts.critical);
  $("#filter-high-count").textContent = pad(counts.high);
  $("#filter-watch-count").textContent = pad(counts.watch);
  $("#track-count-heading").textContent = pad(state.tracks.length);
}

function renderRadar() {
  const svg = $("#radar-svg");
  const sorted = [...state.tracks].sort((a, b) => b.score - a.score);
  const centerX = 520;
  const centerY = 265;
  const radius = 226;
  const ringRadii = [56.5, 113, 169.5, radius];
  const rings = ringRadii.map((ringRadius, index) => `<circle class="radar-ring${index === ringRadii.length - 1 ? " outer" : ""}" cx="${centerX}" cy="${centerY}" r="${ringRadius}"></circle>`).join("");
  const ticks = Array.from({ length: 72 }, (_, index) => {
    const angle = (index * 5 - 90) * Math.PI / 180;
    const major = index % 6 === 0;
    const innerRadius = radius - (major ? 12 : 5);
    const x1 = centerX + Math.cos(angle) * innerRadius;
    const y1 = centerY + Math.sin(angle) * innerRadius;
    const x2 = centerX + Math.cos(angle) * radius;
    const y2 = centerY + Math.sin(angle) * radius;
    return `<line class="radar-tick${major ? " major" : ""}" x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}"></line>`;
  }).join("");
  const rangeLabels = [3, 6, 9, 12].map((range, index) => `<text class="radar-range-label" x="${centerX + 8}" y="${centerY - ringRadii[index] + 4}">${range} KM</text>`).join("");
  const compass = `<text class="radar-compass" x="${centerX}" y="22" text-anchor="middle">N</text><text class="radar-compass" x="770" y="${centerY + 4}" text-anchor="middle">E</text><text class="radar-compass" x="${centerX}" y="526" text-anchor="middle">S</text><text class="radar-compass" x="270" y="${centerY + 4}" text-anchor="middle">W</text>`;
  const grid = `<defs><radialGradient id="radar-field-fill"><stop offset="0%" stop-color="#193c42" stop-opacity=".6"></stop><stop offset="100%" stop-color="#070b0c" stop-opacity=".08"></stop></radialGradient><linearGradient id="radar-sweep-fill" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#d7ff3f" stop-opacity=".02"></stop><stop offset="100%" stop-color="#d7ff3f" stop-opacity=".35"></stop></linearGradient><clipPath id="radar-field-clip"><circle cx="${centerX}" cy="${centerY}" r="${radius}"></circle></clipPath></defs><circle class="radar-field" cx="${centerX}" cy="${centerY}" r="${radius}" fill="url(#radar-field-fill)"></circle>${rings}<line class="radar-axis" x1="${centerX}" y1="${centerY - radius}" x2="${centerX}" y2="${centerY + radius}"></line><line class="radar-axis" x1="${centerX - radius}" y1="${centerY}" x2="${centerX + radius}" y2="${centerY}"></line><line class="radar-axis diagonal" x1="${centerX - 159.8}" y1="${centerY - 159.8}" x2="${centerX + 159.8}" y2="${centerY + 159.8}"></line><line class="radar-axis diagonal" x1="${centerX + 159.8}" y1="${centerY - 159.8}" x2="${centerX - 159.8}" y2="${centerY + 159.8}"></line>${ticks}${rangeLabels}${compass}<circle class="radar-origin" cx="${centerX}" cy="${centerY}" r="3"></circle>`;
  const sweep = `<g class="radar-sweep" clip-path="url(#radar-field-clip)"><path d="M ${centerX} ${centerY} L ${centerX} ${centerY - radius} A ${radius} ${radius} 0 0 1 ${centerX + radius * Math.sin(Math.PI / 8)} ${centerY - radius * Math.cos(Math.PI / 8)} Z" fill="url(#radar-sweep-fill)"></path><line class="radar-sweep-line" x1="${centerX}" y1="${centerY}" x2="${centerX}" y2="${centerY - radius}"></line><animateTransform attributeName="transform" type="rotate" from="0 ${centerX} ${centerY}" to="360 ${centerX} ${centerY}" dur="8s" repeatCount="indefinite"></animateTransform></g>`;
  const zones = `<circle class="zone" cx="${centerX}" cy="${centerY}" r="198"></circle><circle class="core" cx="${centerX}" cy="${centerY}" r="84"></circle>`;
  const trajectories = sorted.map((track) => {
    const points = predictedPoints(track).map((point) => `${point.x * 10},${point.y * 5.4 + 0}`).join(" ");
    const selected = track.id === state.selectedId ? " selected" : "";
    return `<polyline class="trajectory${selected}" points="${points}"></polyline>`;
  }).join("");
  const objects = sorted.map((track) => {
    const x = track.x * 10;
    const y = track.y * 5.4;
    const selected = track.id === state.selectedId;
    const color = colorFor(track.level);
    const ring = selected ? `<circle class="track-ring" cx="${x}" cy="${y}" r="22" stroke="${color}"><animate attributeName="r" values="18;28;18" dur="2.2s" repeatCount="indefinite"></animate><animate attributeName="opacity" values=".75;.15;.75" dur="2.2s" repeatCount="indefinite"></animate></circle>` : "";
    const labelX = x > 760 ? x - 68 : x + 13;
    const labelY = y < 65 ? y + 33 : y - 18;
    return `<g class="track-hit" data-track-id="${track.id}" tabindex="0" role="button" aria-label="Inspect ${track.id}">${ring}<circle class="track-dot" cx="${x}" cy="${y}" r="${selected ? 7 : 5}" fill="${color}"></circle><text class="track-label" x="${labelX}" y="${labelY}">${track.id}</text><text class="track-sub" x="${labelX}" y="${labelY + 13}">${track.score} / ${track.level.toUpperCase()}</text></g>`;
  }).join("");
  svg.innerHTML = `${grid}${sweep}${zones}${trajectories}${objects}`;
  $$("#radar-svg [data-track-id]").forEach((node) => {
    node.addEventListener("click", () => selectTrack(node.dataset.trackId));
    node.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") selectTrack(node.dataset.trackId); });
  });
  $("#sweep-count").textContent = String(state.tick).padStart(3, "0");
  $("#map-time").textContent = `SYNC ${timeLabel()}`;
}

function renderThreatQueue() {
  const list = $("#threat-list");
  let filtered = state.tracks.filter((track) => state.alertFilter === "all" || track.level === state.alertFilter);
  filtered = [...filtered].sort((a, b) => state.sortThreat ? b.score - a.score : a.id.localeCompare(b.id));
  if (!filtered.length) { list.innerHTML = `<div class="detail-empty"><div><div class="detail-empty-icon">✓</div>No tracks in this filter.<br />The queue is quiet for now.</div></div>`; return; }
  list.innerHTML = filtered.slice(0, 7).map((track) => {
    const acked = Boolean(state.acknowledged[track.id]);
    return `<div class="threat-row ${track.id === state.selectedId ? "selected" : ""}" data-threat-id="${track.id}"><span class="threat-severity ${track.level}"></span><div class="threat-main"><div class="threat-heading"><strong>${track.id} / ${track.callsign}</strong><span>${track.eta}s ETA</span></div><div class="threat-reason">${escapeHtml(track.reasons[0])}</div><div class="threat-meta"><span class="severity-label ${track.level}">${track.level.toUpperCase()}</span><span>Score ${track.score}</span><span>${track.restricted ? "ZONE ENTRY" : "VECTOR"}</span></div></div><button class="ack-button ${acked ? "acked" : ""}" data-ack-id="${track.id}" aria-label="${acked ? "Acknowledged" : "Acknowledge"} ${track.id}">${acked ? "✓" : "○"}</button></div>`;
  }).join("");
  $$("[data-threat-id]").forEach((row) => row.addEventListener("click", () => selectTrack(row.dataset.threatId)));
  $$("[data-ack-id]").forEach((button) => button.addEventListener("click", (event) => { event.stopPropagation(); state.acknowledged[button.dataset.ackId] = !state.acknowledged[button.dataset.ackId]; saveState(); renderThreatQueue(); }));
}

function renderTable() {
  const tbody = $("#track-table-body");
  const rows = [...state.tracks].sort((a, b) => state.sortThreat ? b.score - a.score : a.id.localeCompare(b.id));
  tbody.innerHTML = rows.map((track) => `<tr class="${track.id === state.selectedId ? "selected" : ""}" data-table-id="${track.id}"><td><span class="track-identity">${track.id}<small>${track.callsign}</small></span></td><td><span class="class-pill">${track.type}</span></td><td>${numberLabel(track.altitude)} m</td><td>${track.speed} kt</td><td>${String(track.heading).padStart(3, "0")}°</td><td><span class="threat-score ${track.level}">${track.score}</span></td><td><span class="state-pill ${track.level === "critical" || track.level === "high" ? "alert" : track.behavior === "steady" ? "moving" : ""}">${track.level === "critical" ? "ESCALATED" : track.level === "high" ? "WATCH" : "TRACKING"}</span></td></tr>`).join("");
  $$("[data-table-id]").forEach((row) => row.addEventListener("click", () => selectTrack(row.dataset.tableId)));
}

function chartMarkup(track) {
  const values = track.history.length ? track.history : [track.altitude];
  const min = Math.min(...values) - 80;
  const max = Math.max(...values) + 80;
  const points = values.map((value, index) => `${(index / Math.max(values.length - 1, 1)) * 100},${62 - ((value - min) / Math.max(max - min, 1)) * 48}`).join(" ");
  return `<svg class="activity-chart" viewBox="0 0 100 70" preserveAspectRatio="none" aria-label="Altitude history chart"><line x1="0" y1="17" x2="100" y2="17" stroke="#e2eef0" stroke-width=".7"></line><line x1="0" y1="40" x2="100" y2="40" stroke="#e2eef0" stroke-width=".7"></line><line x1="0" y1="63" x2="100" y2="63" stroke="#e2eef0" stroke-width=".7"></line><polyline points="${points}" fill="none" stroke="#00a7bd" stroke-width="2" vector-effect="non-scaling-stroke"></polyline><circle cx="100" cy="${62 - ((values.at(-1) - min) / Math.max(max - min, 1)) * 48}" r="2.5" fill="#d65458"></circle></svg>`;
}

function renderDetail() {
  const track = state.tracks.find((item) => item.id === state.selectedId);
  const content = $("#detail-content");
  if (!track) { $("#detail-title").textContent = "Select a track"; content.innerHTML = `<div class="detail-empty"><div><div class="detail-empty-icon">⌖</div>Select an object on the radar or in the catalogue<br />to open its investigation lens.</div></div>`; return; }
  $("#detail-title").textContent = `${track.id} / ${track.callsign}`;
  const color = colorFor(track.level);
  const rationale = [
    ["Proximity", track.proximity, `${track.proximity}%`],
    ["Behavior", track.behaviorScore, track.behavior],
    ["Zone entry", track.restricted ? 100 : 7, track.restricted ? "restricted" : "clear"],
    ["Confidence gap", track.lowConfidence, `${track.confidence}% conf.`]
  ];
  content.innerHTML = `<div class="detail-top"><div class="score-ring" style="--score:${track.score * 3.6}deg; background:conic-gradient(${color} var(--score), #edf3f5 0)"><strong>${track.score}</strong><small>THREAT</small></div><div class="detail-headline"><h3>${track.type}</h3><p>${track.home} · VECTOR ${String(track.heading).padStart(3, "0")}°</p><div class="detail-badges"><span class="detail-badge red">${track.level.toUpperCase()}</span><span class="detail-badge blue">${track.confidence}% CLASS CONF.</span></div></div></div><div class="telemetry-grid"><div class="telemetry-cell"><span>ALTITUDE</span><strong>${numberLabel(track.altitude)} m</strong></div><div class="telemetry-cell"><span>SPEED</span><strong>${track.speed} kt</strong></div><div class="telemetry-cell"><span>ETA / CORE</span><strong>${track.eta} sec</strong></div></div><div class="section-label"><span>THREAT RATIONALE</span><span>WEIGHTED / EXPLAINABLE</span></div><div class="rationale-list">${rationale.map(([label, value, text]) => `<div><div class="rationale-item"><span>${label}</span><span>${escapeHtml(text)}</span></div><div class="rationale-bar"><i style="width:${value}%"></i></div></div>`).join("")}</div><div class="section-label"><span>ALTITUDE HISTORY</span><span>LAST 18 TICKS</span></div>${chartMarkup(track)}<div class="section-label"><span>EVENT TIMELINE</span><span>${state.events.length} EVENTS</span></div><div class="timeline">${state.events.slice(0, 4).map((event) => `<div class="timeline-item"><i style="background:${event.tone === "red" ? "#d65458" : event.tone === "amber" ? "#e59c2b" : event.tone === "violet" ? "#705bd7" : "#00a7bd"}"></i><time>${event.time}</time><span><strong>${escapeHtml(event.label)}</strong> · ${escapeHtml(event.detail)}</span></div>`).join("")}</div>`;
}

function renderAll() {
  renderMetrics(); renderRadar(); renderThreatQueue(); renderTable(); renderDetail();
  $("#last-tick").textContent = `#${String(state.tick).padStart(3, "0")}`;
  $("#scenario-description").textContent = scenarioMeta[state.scenario].label;
  $("#pause-button").innerHTML = `<span class="button-icon">${state.paused ? "▶" : "Ⅱ"}</span><span>${state.paused ? "Resume" : "Pause"}</span>`;
  document.body.classList.toggle("simulation-paused", state.paused);
}

function selectTrack(id) {
  state.selectedId = id;
  addEvent("Track focused", `${id} opened in investigation lens`, "violet");
  renderAll();
  if (window.innerWidth < 980) $("#systems-section").scrollIntoView({ behavior: "smooth", block: "start" });
}

function syncControls() {
  $("#scenario-select").value = state.scenario;
  $("#speed-select").value = state.speed;
  $$("[data-alert-filter]").forEach((button) => button.classList.toggle("active", button.dataset.alertFilter === state.alertFilter));
}

function updateConnection(online) {
  state.online = online;
  $("#connection-label").textContent = online ? "CONNECTED" : "OFFLINE / CACHED";
  $("#connection-pill").style.color = online ? "var(--green)" : "var(--amber)";
  restartTimer();
  addEvent(online ? "Connection restored" : "Low-bandwidth mode", online ? "Normal telemetry cadence resumed" : "Core shell cached; update cadence reduced", online ? "green" : "amber");
  renderAll();
}

function setLocationStatus(message, tone = "amber") {
  const status = $("#location-status");
  if (status) status.innerHTML = `<span class="status-dot ${tone}"></span>${escapeHtml(message)}`;
}

let locationLookupSequence = 0;

function clearLocationMapPreviews(message = "Awaiting coordinates") {
  const mapImage = $("#location-map-image");
  const satelliteImage = $("#location-satellite-image");
  mapImage.onload = null;
  mapImage.onerror = null;
  mapImage.removeAttribute("src");
  mapImage.hidden = true;
  satelliteImage.onload = null;
  satelliteImage.onerror = null;
  satelliteImage.removeAttribute("src");
  satelliteImage.hidden = true;
  $("#location-map-marker").hidden = true;
  $("#location-satellite-marker").hidden = true;
  [$("#location-map-open"), $("#location-satellite-open")].forEach((link) => {
    link.removeAttribute("href");
    link.setAttribute("aria-disabled", "true");
    link.tabIndex = -1;
  });
  $("#location-map-empty").textContent = message.toUpperCase();
  $("#location-map-empty").hidden = false;
  $("#location-satellite-empty").textContent = message.toUpperCase();
  $("#location-satellite-empty").hidden = false;
  $("#location-coordinates").textContent = "--";
  $("#location-coordinate-source").textContent = message;
}

function updateLocationMaps(latitude, longitude, source) {
  const lat = Number(latitude);
  const lon = Number(longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    clearLocationMapPreviews("Coordinates unavailable");
    return false;
  }

  $("#location-coordinates").textContent = `${lat.toFixed(6)}, ${lon.toFixed(6)}`;
  $("#location-coordinate-source").textContent = source;
  const halfLat = 0.004;
  const halfLon = Math.min(halfLat * (16 / 9) / Math.max(Math.abs(Math.cos(lat * Math.PI / 180)), 0.15), 2);
  const south = Math.max(-90, lat - halfLat);
  const north = Math.min(90, lat + halfLat);
  const west = Math.max(-180, lon - halfLon);
  const east = Math.min(180, lon + halfLon);
  const bbox = `${west.toFixed(6)},${south.toFixed(6)},${east.toFixed(6)},${north.toFixed(6)}`;
  const markerLeft = Math.max(0, Math.min(100, ((lon - west) / (east - west)) * 100));
  const markerTop = Math.max(0, Math.min(100, ((north - lat) / (north - south)) * 100));
  [$("#location-map-marker"), $("#location-satellite-marker")].forEach((marker) => {
    marker.style.left = `${markerLeft}%`;
    marker.style.top = `${markerTop}%`;
  });

  const mapUrl = new URL("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/export");
  mapUrl.searchParams.set("bbox", bbox);
  mapUrl.searchParams.set("bboxSR", "4326");
  mapUrl.searchParams.set("imageSR", "4326");
  mapUrl.searchParams.set("size", "640,360");
  mapUrl.searchParams.set("format", "png32");
  mapUrl.searchParams.set("f", "image");
  const mapOpenUrl = new URL("https://www.openstreetmap.org/");
  mapOpenUrl.searchParams.set("mlat", lat.toFixed(6));
  mapOpenUrl.searchParams.set("mlon", lon.toFixed(6));
  mapOpenUrl.hash = `map=16/${lat.toFixed(6)}/${lon.toFixed(6)}`;
  const mapOpen = $("#location-map-open");
  mapOpen.href = mapOpenUrl.toString();
  mapOpen.setAttribute("aria-disabled", "false");
  mapOpen.tabIndex = 0;
  mapOpen.title = `Open interactive street map at ${lat.toFixed(6)}, ${lon.toFixed(6)}`;
  const mapImage = $("#location-map-image");
  const mapEmpty = $("#location-map-empty");
  mapEmpty.textContent = "LOADING LOCAL MAP";
  mapEmpty.hidden = false;
  mapImage.alt = `Street map centered at ${lat.toFixed(6)}, ${lon.toFixed(6)}`;
  mapImage.onload = () => {
    mapImage.hidden = false;
    $("#location-map-marker").hidden = false;
    mapEmpty.hidden = true;
  };
  mapImage.onerror = () => {
    mapImage.hidden = true;
    $("#location-map-marker").hidden = true;
    mapEmpty.textContent = "LOCAL MAP UNAVAILABLE · OPEN INTERACTIVE MAP";
    mapEmpty.hidden = false;
  };
  mapImage.hidden = false;
  mapImage.src = mapUrl.toString();

  const satelliteUrl = new URL("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/export");
  satelliteUrl.searchParams.set("bbox", bbox);
  satelliteUrl.searchParams.set("bboxSR", "4326");
  satelliteUrl.searchParams.set("imageSR", "4326");
  satelliteUrl.searchParams.set("size", "640,360");
  satelliteUrl.searchParams.set("format", "jpg");
  satelliteUrl.searchParams.set("f", "image");
  const satelliteOpenUrl = new URL(satelliteUrl.toString());
  satelliteOpenUrl.searchParams.set("size", "1280,720");
  const satelliteOpen = $("#location-satellite-open");
  satelliteOpen.href = satelliteOpenUrl.toString();
  satelliteOpen.setAttribute("aria-disabled", "false");
  satelliteOpen.tabIndex = 0;
  satelliteOpen.title = `Open high-resolution satellite imagery at ${lat.toFixed(6)}, ${lon.toFixed(6)}`;
  const satelliteImage = $("#location-satellite-image");
  const satelliteEmpty = $("#location-satellite-empty");
  const satelliteMarker = $("#location-satellite-marker");
  satelliteEmpty.textContent = "LOADING IMAGERY";
  satelliteEmpty.hidden = false;
  satelliteMarker.hidden = true;
  satelliteImage.alt = `Satellite imagery near ${lat.toFixed(6)}, ${lon.toFixed(6)}`;
  satelliteImage.onload = () => {
    satelliteImage.hidden = false;
    satelliteMarker.hidden = false;
    satelliteEmpty.hidden = true;
  };
  satelliteImage.onerror = () => {
    satelliteImage.hidden = true;
    satelliteMarker.hidden = true;
    satelliteEmpty.textContent = "IMAGERY UNAVAILABLE";
    satelliteEmpty.hidden = false;
  };
  satelliteImage.hidden = false;
  satelliteImage.src = satelliteUrl.toString();
  return true;
}

async function reverseGeocode(lat, lon, source = "OpenStreetMap / Nominatim", lookupSequence = null) {
  $("#reverse-source").textContent = source;
  try {
    const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&zoom=14`, { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error("reverse lookup unavailable");
    const data = await response.json();
    if (lookupSequence !== null && lookupSequence !== locationLookupSequence) return;
    const address = data.address || {};
    const label = [address.city || address.town || address.village || address.state_district, address.state || address.country].filter(Boolean).join(", ");
    $("#reverse-location").textContent = label || data.display_name?.split(",").slice(0, 2).join(",") || "Coordinates resolved";
  } catch (_) {
    if (lookupSequence !== null && lookupSequence !== locationLookupSequence) return;
    $("#reverse-location").textContent = "Reverse lookup unavailable";
  }
}

function applyDeviceLocation(position) {
  const { latitude, longitude, accuracy } = position.coords;
  deviceLocation = { latitude, longitude, accuracy };
  $("#device-coordinates").textContent = `${latitude.toFixed(6)}° / ${longitude.toFixed(6)}° · GPS`;
  $("#location-accuracy").textContent = `${Math.round(accuracy)} m GPS`;
  $("#location-source").textContent = "Browser geolocation sensor";
  updateLocationMaps(latitude, longitude, `GPS fix · ±${Math.round(accuracy)} m reported accuracy`);
  setLocationStatus(deviceWatchId !== null ? "Live device tracking active." : "Device position acquired.", "green");
  reverseGeocode(latitude, longitude);
}

function startDeviceTracking() {
  if (!navigator.geolocation) { setLocationStatus("Browser geolocation is not available on this device.", "red"); return; }
  if (deviceWatchId !== null) {
    navigator.geolocation.clearWatch(deviceWatchId);
    deviceWatchId = null;
    $("#device-location-button").textContent = "⌖ START DEVICE TRACKING";
    setLocationStatus("Device tracking paused. Last position retained.", "amber");
    return;
  }
  setLocationStatus("Requesting device permission…", "amber");
  deviceWatchId = navigator.geolocation.watchPosition(applyDeviceLocation, (error) => {
    deviceWatchId = null;
    $("#device-location-button").textContent = "⌖ START DEVICE TRACKING";
    setLocationStatus(`Device location unavailable: ${error.message}`, "red");
  }, { enableHighAccuracy: true, maximumAge: 15000, timeout: 12000 });
  $("#device-location-button").textContent = "■ STOP DEVICE TRACKING";
}

function isValidIpAddress(value) {
  const ip = value.trim();
  if (!ip || ip.length > 45) return false;
  const octets = ip.split(".");
  if (octets.length === 4) {
    return octets.every((octet) => /^(0|[1-9]\d{0,2})$/.test(octet) && Number(octet) <= 255);
  }
  if (!ip.includes(":")) return false;
  try {
    const hostname = new URL(`http://[${ip}]/`).hostname;
    return hostname.startsWith("[") && hostname.endsWith("]") && hostname.includes(":");
  } catch (_) {
    return false;
  }
}

async function refreshNetworkLocation(targetIp = null) {
  const lookupSequence = ++locationLookupSequence;
  const requestedIp = targetIp?.trim() || null;
  if (!state.online) { setLocationStatus("Offline: using cached telemetry; network location paused.", "amber"); return; }
  setLocationStatus(requestedIp ? `Querying IP location for ${requestedIp}…` : "Querying IP signal providers…", "amber");
  clearLocationMapPreviews(requestedIp ? "IP lookup in progress" : "Querying current IP");
  if (requestedIp) {
    $("#network-ip").textContent = requestedIp;
    $("#network-provider").textContent = "Querying providers…";
    $("#reverse-location").textContent = "Looking up…";
    $("#reverse-source").textContent = "IP location estimate";
    $("#location-accuracy").textContent = "Pending";
    $("#location-source").textContent = "Public IP lookup";
    $("#device-coordinates").textContent = `IP SIGNAL / ${requestedIp}`;
  }
  const encodedIp = requestedIp ? `${encodeURIComponent(requestedIp)}/` : "";
  const [ipapiResult, geojsResult] = await Promise.allSettled([
    fetch(`https://ipapi.co/${encodedIp}json/`).then((response) => response.ok ? response.json() : Promise.reject(new Error("ipapi unavailable"))),
    fetch(`https://get.geojs.io/v1/ip/geo/${requestedIp ? `${encodeURIComponent(requestedIp)}.json` : "geo.json"}`).then((response) => response.ok ? response.json() : Promise.reject(new Error("GeoJS unavailable")))
  ]);
  if (lookupSequence !== locationLookupSequence) return;
  const usableLocation = (result) => {
    if (result.status !== "fulfilled") return null;
    const data = Array.isArray(result.value) ? result.value[0] : result.value;
    if (!data || data.error) return null;
    return data.city || data.country_name || data.country || data.latitude != null || data.longitude != null ? data : null;
  };
  const ipapi = usableLocation(ipapiResult);
  const geojs = usableLocation(geojsResult);
  const network = ipapi || geojs;
  if (!network) {
    if (requestedIp) {
      $("#network-provider").textContent = "No provider response";
      $("#reverse-location").textContent = "Lookup unavailable";
      $("#reverse-source").textContent = "No location returned";
      $("#location-accuracy").textContent = "--";
      $("#location-source").textContent = "No estimate available";
      $("#device-coordinates").textContent = "IP SIGNAL / LOOKUP FAILED";
    }
    clearLocationMapPreviews("IP location unavailable");
    setLocationStatus("IP providers did not return a location. Try another IP address.", "red");
    return;
  }
  const ip = network.ip || geojs?.ip || requestedIp || "Unavailable";
  const city = network.city || geojs?.city || "Unknown city";
  const region = network.region || geojs?.region || "";
  const country = network.country_name || network.country || geojs?.country || "";
  const lat = Number(network.latitude ?? geojs?.latitude);
  const lon = Number(network.longitude ?? geojs?.longitude);
  const provider = ipapi ? "ipapi.co" : "GeoJS";
  $("#network-ip").textContent = ip;
  $("#network-provider").textContent = `${provider} · ${[city, region, country].filter(Boolean).join(", ")}`;
  if (Number.isFinite(lat) && Number.isFinite(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
    $("#device-coordinates").textContent = `${lat.toFixed(6)}° / ${lon.toFixed(6)}° · IP SIGNAL`;
    $("#location-accuracy").textContent = "City-level estimate";
    $("#location-source").textContent = `${city}, ${country} · network signal`;
    updateLocationMaps(lat, lon, `IP geolocation estimate · ${provider} · not an exact device fix`);
    reverseGeocode(lat, lon, `OpenStreetMap / Nominatim · ${provider} IP estimate`, lookupSequence);
  } else {
    $("#reverse-location").textContent = [city, region, country].filter(Boolean).join(", ") || "Location unavailable";
    $("#reverse-source").textContent = `${provider} · IP estimate`;
    $("#location-accuracy").textContent = "City-level estimate";
    $("#location-source").textContent = `${city}, ${country} · network signal`;
    $("#device-coordinates").textContent = "IP SIGNAL / COORDINATES UNAVAILABLE";
    clearLocationMapPreviews("Provider returned no coordinates");
  }
  setLocationStatus(`${requestedIp ? `Estimate for ${ip}` : "IP location"} resolved via ${provider}.`, "green");
}

function lookupSpecifiedIp() {
  const input = $("#ip-address-input");
  const ip = input.value.trim();
  if (!isValidIpAddress(ip)) {
    input.setCustomValidity("Enter a valid IPv4 or IPv6 address.");
    input.reportValidity();
    setLocationStatus("Enter a valid IPv4 or IPv6 address to look it up.", "red");
    return;
  }
  input.setCustomValidity("");
  input.value = ip;
  refreshNetworkLocation(ip);
}

function wireEvents() {
  $("#scenario-select").addEventListener("change", (event) => { state.scenario = event.target.value; resetSimulation(true); });
  $("#speed-select").addEventListener("change", (event) => { state.speed = event.target.value; restartTimer(); saveState(); renderAll(); });
  $("#pause-button").addEventListener("click", () => { state.paused = !state.paused; addEvent(state.paused ? "Simulation paused" : "Simulation resumed", state.paused ? "Telemetry frozen for review" : "Live simulation cadence resumed", "violet"); renderAll(); });
  $("#reset-button").addEventListener("click", () => resetSimulation(true));
  $("#sort-threat-button").addEventListener("click", () => { state.sortThreat = !state.sortThreat; renderTable(); renderThreatQueue(); });
  $("#clear-ack-button").addEventListener("click", () => { state.acknowledged = {}; saveState(); renderThreatQueue(); });
  $("#map-focus-button").addEventListener("click", () => { const node = document.querySelector(`[data-track-id="${state.selectedId}"]`); node?.scrollIntoView({ behavior: "smooth", block: "center" }); });
  $$("[data-alert-filter]").forEach((button) => button.addEventListener("click", () => { state.alertFilter = button.dataset.alertFilter; syncControls(); renderThreatQueue(); }));
  $$("[data-view]").forEach((button) => button.addEventListener("click", () => { $$("[data-view]").forEach((item) => item.classList.remove("active")); button.classList.add("active"); const target = { overview: "overview-section", tracks: "tracks-section", alerts: "alerts-section", location: "location-section", systems: "systems-section" }[button.dataset.view]; document.getElementById(target)?.scrollIntoView({ behavior: "smooth", block: "start" }); }));
  $("#device-location-button").addEventListener("click", startDeviceTracking);
  $("#ip-location-button").addEventListener("click", refreshNetworkLocation);
  const ipInput = $("#ip-address-input");
  ipInput.addEventListener("input", () => ipInput.setCustomValidity(""));
  $("#ip-lookup-form").addEventListener("submit", (event) => { event.preventDefault(); lookupSpecifiedIp(); });
  window.addEventListener("online", () => updateConnection(true));
  window.addEventListener("offline", () => updateConnection(false));
  window.addEventListener("beforeinstallprompt", (event) => { event.preventDefault(); deferredInstall = event; $("#install-button").hidden = false; });
  $("#install-button").addEventListener("click", async () => { if (!deferredInstall) return; deferredInstall.prompt(); deferredInstall = null; $("#install-button").hidden = true; });
}

function startClock() { setInterval(() => { $("#clock").textContent = `${timeLabel()} UTC`; }, 1000); $("#clock").textContent = `${timeLabel()} UTC`; }

function finishBootSequence(force = false) {
  if (!force && sessionStorage.getItem(ACCESS_KEY) !== "granted") return;
  window.setTimeout(() => $("#boot-loader")?.classList.add("is-ready"), 1200);
}

function setupSystemGate() {
  const gate = $("#system-gate");
  const accessButton = $("#system-access-button");
  const loginForm = $("#system-login-form");
  const status = $("#login-status");
  if (!gate) return;
  if (sessionStorage.getItem(ACCESS_KEY) === "granted") {
    gate.remove();
    document.body.classList.remove("gate-locked");
    return;
  }
  document.body.classList.add("gate-locked");
  accessButton.addEventListener("click", () => {
    loginForm.hidden = false;
    accessButton.classList.add("is-active");
    $("#login-callsign")?.focus();
  });
  loginForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const callsign = $("#login-callsign").value.trim().toLowerCase();
    const key = $("#login-key").value.trim();
    if ((callsign === "operator" && key === "aegis2026") || (callsign === "demo" && key === "aegis")) {
      sessionStorage.setItem(ACCESS_KEY, "granted");
      status.textContent = "SESSION ACCEPTED / INITIALIZING COMMAND DECK";
      status.classList.remove("error");
      document.body.classList.remove("gate-locked");
      $("#boot-loader")?.classList.remove("is-ready");
      gate.classList.add("is-exiting");
      window.setTimeout(() => { gate.remove(); finishBootSequence(true); }, 560);
    } else {
      status.textContent = "ACCESS DENIED / USE OPERATOR DEMO CREDENTIALS";
      status.classList.add("error");
    }
  });
}

async function initServiceWorker() {
  if ("serviceWorker" in navigator) { try { await navigator.serviceWorker.register("/sw.js"); } catch (_) { /* the dashboard remains fully usable without the app shell */ } }
}

setupSystemGate();
loadState();
wireEvents();
syncControls();
startClock();
refreshNetworkLocation();
initServiceWorker();
finishBootSequence();
